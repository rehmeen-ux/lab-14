MINI SHOP - LAB 14

1. Extract this ZIP file.
2. Open the extracted "mini-shop-lab14" folder in VS Code.
3. Open Terminal > New Terminal.
4. Run:
      npm install
5. Then run:
      npm run dev
6. Open the localhost address shown in the terminal (usually http://localhost:5173).

IMPORTANT:
- Replace YOUR NAME and YOUR REGISTRATION NUMBER comments in each source file with your own details.
- Do not submit node_modules.
- To check the production build, run: npm run build
