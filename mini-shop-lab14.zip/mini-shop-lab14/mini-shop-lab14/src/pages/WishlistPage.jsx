// Name: YOUR NAME
// Registration No: YOUR REGISTRATION NUMBER

import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import products from "../products";
import { selectWishIds, clearWish, toggleWish } from "../store/wishlistSlice";

function WishlistPage() {
  const dispatch = useDispatch();
  const wishIds = useSelector(selectWishIds);
  const wishedProducts = products.filter((product) => wishIds.includes(product.id));

  return (
    <section>
      <div className="page-heading">
        <h1>My Wishlist</h1>
        {wishedProducts.length > 0 && (
          <button className="secondary-button" onClick={() => dispatch(clearWish())}>
            Clear Wishlist
          </button>
        )}
      </div>

      {wishedProducts.length === 0 ? (
        <p className="empty-message">Your wishlist is empty. Go to Home and add some products.</p>
      ) : (
        <div className="products">
          {wishedProducts.map((product) => (
            <article className="product-card" key={product.id}>
              <h3>{product.title}</h3>
              <p>Category: {product.category}</p>
              <p>Price: Rs. {product.price}</p>
              <div className="card-actions">
                <Link to={`/product/${product.id}`}>View Details</Link>
                <button className="remove-button" onClick={() => dispatch(toggleWish(product.id))}>
                  Remove
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}

export default WishlistPage;