
import { useLocation, useNavigate } from "react-router-dom";

function OrderSuccess() {
  const location = useLocation();
  const navigate = useNavigate();

  let order = location.state?.order || null;

  if (!order) {
    try {
      order = JSON.parse(localStorage.getItem("lastOrder"));
    } catch {
      order = null;
    }
  }

  if (!order || !order.customer) {
    return (
      <div className="checkout-page">
        <h1>No Order Found</h1>
        <button className="btn-order" onClick={() => navigate("/")}>
          Go to Home
        </button>
      </div>
    );
  }

  const { customer, items = [], total, payment, id } = order;

  return (
    <div className="checkout-page">
      <h1>Order Placed Successfully 🎉</h1>
      <p className="checkout-subtitle">
        Thank you, {customer.fullName}. Your order #{id} has been received.
      </p>

      <div className="checkout-card">
        <h3>Delivery Details</h3>
        <p><strong>Name:</strong> {customer.fullName}</p>
        <p><strong>Email:</strong> {customer.email}</p>
        <p><strong>Phone:</strong> {customer.phone}</p>
        <p><strong>Address:</strong> {customer.address}, {customer.city}</p>
        <p><strong>Payment:</strong> {payment}</p>

        <h3>Items</h3>
        {items.map((item, index) => (
          <p key={item.id ?? index}>
            {item.title || item.name} × {item.quantity ?? item.qty ?? 1} — Rs.{" "}
            {Number(item.price || 0) * Number(item.quantity ?? item.qty ?? 1)}
          </p>
        ))}

        <p className="total">Total Amount: Rs. {total}</p>

        <button className="btn-order" onClick={() => navigate("/")}>
          Continue Shopping
        </button>
      </div>
    </div>
  );
}

export default OrderSuccess;