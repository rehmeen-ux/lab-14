

import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import {
  selectCartItems,
  increaseQuantity,
  decreaseQuantity,
  removeFromCart,
  clearCart
} from "../store/cartSlice";

function CartPage() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const cartItems = useSelector(selectCartItems);

  const totalPrice = cartItems.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  return (
    <div className="container">
      <h1>Shopping Cart</h1>

      {cartItems.length === 0 ? (
        <p className="empty-message">
          Your cart is empty. Add some products!
        </p>
      ) : (
        <>
          {cartItems.map((item) => (
            <div className="product-card" key={item.id}>
              <h3>{item.title}</h3>

              <p>Price: Rs. {item.price}</p>

              <p>Quantity: {item.quantity}</p>

              <p>
                Subtotal: Rs. {item.price * item.quantity}
              </p>

              <button onClick={() => dispatch(decreaseQuantity(item.id))}>
                -
              </button>

              <button onClick={() => dispatch(increaseQuantity(item.id))}>
                +
              </button>

              <button
                className="remove-button"
                onClick={() => dispatch(removeFromCart(item.id))}
              >
                Remove
              </button>
            </div>
          ))}

          <h2>Total: Rs. {totalPrice}</h2>

          <button onClick={() => dispatch(clearCart())}>
            Clear Cart
          </button>

          <button onClick={() => navigate("/checkout")}>
            Go to Checkout
          </button>
        </>
      )}
    </div>
  );
}

export default CartPage;


