

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

function CheckoutPage() {
  const navigate = useNavigate();

  const cart = useSelector((state) => state.cart);
  const cartItems = Array.isArray(cart)
    ? cart
    : cart?.items || cart?.cartItems || [];

  const total = cartItems.reduce(
    (sum, item) =>
      sum + Number(item.price || 0) * Number(item.quantity ?? item.qty ?? 1),
    0
  );

  const [form, setForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    payment: "cod",
    terms: false,
  });
  const [errors, setErrors] = useState({});

  const validate = (values) => {
    const e = {};
    if (!values.fullName.trim()) e.fullName = "Please enter your full name.";

    if (!values.email.trim()) e.email = "Please enter your email address.";
    else if (!/^\S+@\S+\.\S+$/.test(values.email))
      e.email = "Please enter a valid email address.";

    if (!values.phone.trim()) e.phone = "Please enter your phone number.";
    else if (!/^03\d{9}$/.test(values.phone))
      e.phone = "Phone number must be 11 digits, e.g. 03XXXXXXXXX.";

    if (!values.address.trim())
      e.address = "Please enter your delivery address.";
    if (!values.city.trim()) e.city = "Please enter your city.";
    if (!values.terms) e.terms = "You must accept the Terms and Conditions.";
    return e;
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));

    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = validate(form);
    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) return;

    const order = {
      id: Date.now(),
      customer: {
        fullName: form.fullName.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
        address: form.address.trim(),
        city: form.city.trim(),
      },
      payment: form.payment === "cod" ? "Cash on Delivery" : "Bank Transfer",
      items: cartItems,
      total,
    };

    // save so the success page can always find it (even after refresh)
    localStorage.setItem("lastOrder", JSON.stringify(order));
    navigate("/order-success", { state: { order } });
  };

  if (cartItems.length === 0) {
    return (
      <div className="checkout-page">
        <h1>Checkout</h1>
        <p className="checkout-subtitle">Your cart is empty.</p>
        <button className="btn-order" onClick={() => navigate("/")}>
          Go to Home
        </button>
      </div>
    );
  }

  return (
    <div className="checkout-page">
      <h1>Checkout</h1>
      <p className="checkout-subtitle">Please enter your delivery details.</p>

      <form className="checkout-card" onSubmit={handleSubmit} noValidate>
        <div className={`form-group ${errors.fullName ? "invalid" : ""}`}>
          <label htmlFor="fullName">Full Name</label>
          <input
            type="text"
            id="fullName"
            name="fullName"
            placeholder="Enter your full name"
            value={form.fullName}
            onChange={handleChange}
          />
          {errors.fullName && <small className="error-msg">{errors.fullName}</small>}
        </div>

        <div className={`form-group ${errors.email ? "invalid" : ""}`}>
          <label htmlFor="email">Email Address</label>
          <input
            type="email"
            id="email"
            name="email"
            placeholder="Enter your email"
            value={form.email}
            onChange={handleChange}
          />
          {errors.email && <small className="error-msg">{errors.email}</small>}
        </div>

        <div className={`form-group ${errors.phone ? "invalid" : ""}`}>
          <label htmlFor="phone">Phone Number</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            placeholder="03XXXXXXXXX"
            value={form.phone}
            onChange={handleChange}
          />
          {errors.phone && <small className="error-msg">{errors.phone}</small>}
        </div>

        <div className={`form-group ${errors.address ? "invalid" : ""}`}>
          <label htmlFor="address">Delivery Address</label>
          <textarea
            id="address"
            name="address"
            rows="4"
            placeholder="Enter your delivery address"
            value={form.address}
            onChange={handleChange}
          />
          {errors.address && <small className="error-msg">{errors.address}</small>}
        </div>

        <div className={`form-group ${errors.city ? "invalid" : ""}`}>
          <label htmlFor="city">City</label>
          <input
            type="text"
            id="city"
            name="city"
            placeholder="Enter your city"
            value={form.city}
            onChange={handleChange}
          />
          {errors.city && <small className="error-msg">{errors.city}</small>}
        </div>

        <div className="form-group">
          <label>Payment Method</label>
          <div className="option-row">
            <input
              type="radio"
              id="cod"
              name="payment"
              value="cod"
              checked={form.payment === "cod"}
              onChange={handleChange}
            />
            <label htmlFor="cod">Cash on Delivery</label>
          </div>
          <div className="option-row">
            <input
              type="radio"
              id="bank"
              name="payment"
              value="bank"
              checked={form.payment === "bank"}
              onChange={handleChange}
            />
            <label htmlFor="bank">Bank Transfer</label>
          </div>
        </div>

        <div className={`form-group ${errors.terms ? "invalid" : ""}`}>
          <div className="option-row">
            <input
              type="checkbox"
              id="terms"
              name="terms"
              checked={form.terms}
              onChange={handleChange}
            />
            <label htmlFor="terms">I accept the Terms and Conditions</label>
          </div>
          {errors.terms && <small className="error-msg">{errors.terms}</small>}
        </div>

        <p className="total">Total Amount: Rs. {total}</p>

        <button type="submit" className="btn-order">
          Place Order
        </button>
      </form>
    </div>
  );
}

export default CheckoutPage;