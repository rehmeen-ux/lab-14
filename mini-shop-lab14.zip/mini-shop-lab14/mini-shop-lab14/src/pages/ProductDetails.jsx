// Name: YOUR NAME
// Registration No: YOUR REGISTRATION NUMBER

import { Link, useParams } from "react-router-dom";
import products from "../products";

function ProductDetails() {
  const { id } = useParams();
  const product = products.find((item) => item.id === Number(id));

  if (!product) {
    return (
      <section>
        <h1>Product Not Found</h1>
        <Link to="/">Go Home</Link>
      </section>
    );
  }

  return (
    <section className="details-card">
      <h1>{product.title}</h1>
      <p><strong>Category:</strong> {product.category}</p>
      <p><strong>Price:</strong> Rs. {product.price}</p>
      <Link to="/">Back to Home</Link>
    </section>
  );
}

export default ProductDetails;