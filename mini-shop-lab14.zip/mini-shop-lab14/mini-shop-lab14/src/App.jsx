
// Name: YOUR NAME
// Registration No: YOUR REGISTRATION NUMBER
import CheckoutPage from "./pages/CheckoutPage";
import OrderSuccess from "./pages/OrderSuccess";
import { Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";
import HomePage from "./pages/HomePage";
import WishlistPage from "./pages/WishlistPage";
import ProductDetails from "./pages/ProductDetails";
import CartPage from "./pages/CartPage";

function App() {
  return (
    <div>
      <Navbar />

      <Routes>
        <Route path="/" element={<HomePage />} />

        <Route path="/wishlist" element={<WishlistPage />} />

        <Route path="/cart" element={<CartPage />} />

        <Route
          path="/product/:id"
          element={<ProductDetails />}
        />
<Route path="/checkout" element={<CheckoutPage />} />
<Route path="/order-success" element={<OrderSuccess />} />
        <Route
          path="*"
          element={<h1>404 - Page Not Found</h1>}
        />
      </Routes>
    </div>
  );
}

export default App;

