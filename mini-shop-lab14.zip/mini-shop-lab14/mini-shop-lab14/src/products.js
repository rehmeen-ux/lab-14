// Name: YOUR NAME
// Registration No: YOUR REGISTRATION NUMBER

const products = [
  { id: 1, title: "React Handbook", category: "Books", price: 1200 },
  { id: 2, title: "JavaScript Guide", category: "Books", price: 1000 },
  { id: 3, title: "Wireless Mouse", category: "Electronics", price: 1500 },
  { id: 4, title: "Mechanical Keyboard", category: "Electronics", price: 3500 },
  { id: 5, title: "HTML CSS Notes", category: "Books", price: 700 },
  { id: 6, title: "Laptop Stand", category: "Accessories", price: 2000 }
];

export default products;