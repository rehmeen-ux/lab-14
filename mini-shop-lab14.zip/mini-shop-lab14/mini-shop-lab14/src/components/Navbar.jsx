

// Name: YOUR NAME
// Registration No: YOUR REGISTRATION NUMBER

import { NavLink } from "react-router-dom";
import { useSelector } from "react-redux";

import { selectWishIds } from "../store/wishlistSlice";
import { selectCartItems } from "../store/cartSlice";

function Navbar() {
  const wishIds = useSelector(selectWishIds);
  const cartItems = useSelector(selectCartItems);

  const cartCount = cartItems.reduce(
    (total, item) => total + item.quantity,
    0
  );

  return (
    <nav className="navbar">
      <div className="nav-inner">

        <NavLink to="/" end className="nav-link">
          Mini Shop
        </NavLink>

        <NavLink to="/wishlist" className="nav-link">
          Wishlist ({wishIds.length})
        </NavLink>

        <NavLink to="/cart" className="nav-link">
          Cart ({cartCount})
        </NavLink>

      </div>
    </nav>
  );
}

export default Navbar;

