

// Name: YOUR NAME
// Registration No: YOUR REGISTRATION NUMBER

import { memo } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";

import {
  toggleWish,
  selectWishIds
} from "../store/wishlistSlice";

import { addToCart } from "../store/cartSlice";

function ProductCard({ product }) {
  const dispatch = useDispatch();

  const wishIds = useSelector(selectWishIds);

  const isWished = wishIds.includes(product.id);

  const handleAddToCart = () => {
    dispatch(addToCart(product));
    alert("Product added to cart!");
  };

  return (
    <div className="product-card">
      <h3>{product.title}</h3>

      <p>Category: {product.category}</p>

      <p>Price: Rs. {product.price}</p>

      <button onClick={() => dispatch(toggleWish(product.id))}>
        {isWished ? "Wished" : "Wish"}
      </button>

      <button onClick={handleAddToCart}>
        Add to Cart
      </button>

      <Link to={`/product/${product.id}`}>
        View Details
      </Link>
    </div>
  );
}

export default memo(ProductCard);

